import json
import boto3
import os

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    tabla = dynamodb.Table(os.environ['DYNAMODB_TABLE'])

    try:
        # Assuming the event contains the empleadoId
        print(event)
        empleadoId = event['queryStringParameters']['id']
        response = tabla.get_item(
            Key={
                'empleadoId': empleadoId
            }
        )
        empleado = response.get('Item', {})

        if not empleado:
            return {'statusCode': 404, 'body': json.dumps('Empleado no encontrado.')}
        
        empleado['empleadoId'] += " - EMPLEADO-INE"

        return {
            'statusCode': 200,
            'body': json.dumps(empleado)
        }

    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'body': json.dumps('No se encuentran datos del empleado.')
        }
